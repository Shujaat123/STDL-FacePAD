import torch
import torch.nn as nn
import torchvision.models as models
import numpy as np
from torchvision.transforms import functional as F

class CNNTemporalAvgPooling(nn.Module):
    def __init__(self, num_classes=2):
        super(CNNTemporalAvgPooling, self).__init__()
        # Use MobileNetV3 as the CNN backbone
        self.cnn = models.mobilenet_v3_large(pretrained=True)
        self.cnn.classifier = nn.Identity()  # Remove the classifier to use the feature extractor

        # Adjust the final fully connected layer to match MobileNetV3's feature size (960 instead of 1280)
        self.fc = nn.Linear(960, num_classes)

    def forward(self, x):
        batch_size, seq_len, C, H, W = x.size()  # Expect input as [batch_size, seq_len, channels, height, width]
        out_decision_t = []
        cnn_features = []
        
        for t in range(seq_len):
            # with torch.no_grad():
            feature = self.cnn(x[:, t, :, :, :])  # Extract CNN features for each frame
            cnn_features.append(feature)
            # out_decision_t.append(self.fc(feature))
        
        # Stack features from all frames and average over the temporal dimension (seq_len)
        # out_decision_t = torch.stack(out_decision_t, dim=1)  # Shape: [batch_size, seq_len, 960]
        # out = out_decision_t.mean(dim=1)  # Temporal average pooling: Shape: [batch_size, 960]

        cnn_features = torch.stack(cnn_features, dim=1)  # Shape: [batch_size, seq_len, 960]
        temporal_avg_features = cnn_features.mean(dim=1)  # Temporal average pooling: Shape: [batch_size, 960]

        # Pass through the final fully connected layer
        out = self.fc(temporal_avg_features)  # Shape: [batch_size, num_classes]
        return out

    def extract_intermediate_features(self, x):
        """Extract features before and after LSTM."""
        batch_size, seq_len, C, H, W = x.size()
        cnn_features = []
        for t in range(seq_len):
            # with torch.no_grad():
            feature = self.cnn(x[:, t, :, :, :])  # CNN output (before LSTM)
            cnn_features.append(feature)
        cnn_features = torch.stack(cnn_features, dim=1)  # Shape: [batch_size, seq_len, cnn_output_dim]
        temporal_avg_features = cnn_features.mean(dim=1)  # Temporal average pooling: Shape: [batch_size, 960]
        return cnn_features, temporal_avg_features