from torch.utils.data import Dataset, DataLoader
from torchvision import transforms
from torchvision.transforms import functional as F
import os
import cv2
import random
from PIL import Image
import numpy as np
import torch


class VideoDataset(Dataset):
    def __init__(self, root_dir, transform=None, num_frames=16, is_train=False, dataset_name='not-RA'):
        self.root_dir = root_dir
        self.transform = transform
        self.classes = ['attack', 'real']
        self.num_frames = num_frames
        self.is_train = is_train  # Flag to check if the dataset is for training
        self.dataset_name =  dataset_name
        self.samples = self._load_samples()

    def _load_samples(self):
        samples = []
        for cls in self.classes:
            if ((cls=='attack') and (self.dataset_name=='RA')):
                cls_dir = os.path.join(self.root_dir, cls+'/hand')
                for fname in os.listdir(cls_dir):
                    if (fname.endswith('.mp4') or fname.endswith('.mov')):
                        samples.append((os.path.join(cls_dir, fname), self.classes.index(cls)))
                
                cls_dir = os.path.join(self.root_dir, cls+'/fixed')
                for fname in os.listdir(cls_dir):
                    if (fname.endswith('.mp4') or fname.endswith('.mov')):
                        samples.append((os.path.join(cls_dir, fname), self.classes.index(cls)))
            else:            
                cls_dir = os.path.join(self.root_dir, cls)
                for fname in os.listdir(cls_dir):
                    if (fname.endswith('.mp4') or fname.endswith('.mov')):
                        samples.append((os.path.join(cls_dir, fname), self.classes.index(cls)))
        return samples

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        video_path, label = self.samples[idx]
        frames = self._load_frames(video_path, self.num_frames)
        
        if self.transform:
            frames = [self.transform(frame) for frame in frames]

        # Apply augmentation if training
        if self.is_train:
            angle = 0
            scale = 0
            if random.random() > 0.5:
                angle = random.uniform(-180, 180)  # Random rotation between -180 to 180 degrees
            if random.random() > 0.5:
                scale = random.uniform(0.7, 1.3)  # Random zoom between 70% to 130%
            frames = [self.apply_augmentation(frame, angle, scale) for frame in frames]
        
        frames = torch.stack(frames)
        return frames, label

    def _load_frames(self, video_path, num_frames):
        cap = cv2.VideoCapture(video_path)
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        
        # Ensure the number of frames to load doesn't exceed the total number of frames in the video
        if self.is_train:
            start_frame = np.random.randint(0, max(1, total_frames - num_frames + 1))
        else:
            start_frame = 0
        
        frames = []
        cap.set(cv2.CAP_PROP_POS_FRAMES, start_frame)
        
        for _ in range(num_frames):
            ret, frame = cap.read()
            if not ret:
                break
            frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            frames.append(F.to_tensor(frame))
        
        cap.release()
        
        # If there are not enough frames, repeat the last frame
        while len(frames) < num_frames:
            frames.append(frames[-1])
        
        return frames

    def apply_augmentation(self, image, angle, scale):
        """Apply random augmentations to the image for the training phase."""
        # if random.random() > 0.5:
        #     angle = random.uniform(-180, 180)  # Random rotation between -180 to 180 degrees
        if not(angle==0):
            image = F.rotate(image, angle)
        
        # if random.random() > 0.5:
        #     scale = random.uniform(0.9, 1.1)  # Random zoom between 90% to 110%
        if not(scale==0):
            image = F.affine(image, angle=0, translate=(0, 0), scale=scale, shear=0)
        
        return image

class AdaptiveCenterCropAndResize:
    def __init__(self, output_size):
        """
        Args:
            output_size (tuple or int): The desired output size after resizing (e.g., (32, 32)).
        """
        self.output_size = output_size
        self.to_pil = transforms.ToPILImage()
        self.to_tensor = transforms.ToTensor()

    def __call__(self, img):
        # Convert tensor to PIL image if necessary
        if isinstance(img, torch.Tensor):
            img = self.to_pil(img)

        # Get image size (width, height)
        width, height = img.size

        # Find the minimum dimension to create the largest possible square
        crop_size = min(width, height)

        # Calculate the coordinates to center-crop the square
        left = (width - crop_size) // 2
        top = (height - crop_size) // 2
        right = (width + crop_size) // 2
        bottom = (height + crop_size) // 2

        # Crop the image to the largest square
        img = img.crop((left, top, right, bottom))

        # Resize the cropped square to the desired output size
        img = img.resize(self.output_size, Image.Resampling.LANCZOS)

        # Convert the resized image back to a tensor
        img = self.to_tensor(img)

        return img
    

def collate_fn(batch):
    max_length = max([frames.size(0) for frames, _ in batch])
    padded_frames = []
    labels = []
    for frames, label in batch:
        if frames.size(0) < max_length:
            padding = torch.zeros((max_length - frames.size(0), frames.size(1), frames.size(2), frames.size(3)))
            padded_frames.append(torch.cat((frames, padding), dim=0))
        else:
            padded_frames.append(frames)
        labels.append(label)
    
    padded_frames = torch.stack(padded_frames)
    labels = torch.tensor(labels)
    return padded_frames, labels


