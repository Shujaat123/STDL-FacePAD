from sklearn.manifold import TSNE
import matplotlib.pyplot as plt
import torch


def visualize_tsne_before_after_lstm(model, loader, device):
    # Extract features before and after LSTM
    features_before_lstm, features_after_lstm, labels_list = extract_features(model, loader, device)
    
    # Apply t-SNE
    tsne_before_lstm = apply_tsne(features_before_lstm)
    # tsne_after_lstm = apply_tsne(features_after_lstm)
    
    # Plot the t-SNE results
    plot_tsne(tsne_before_lstm, labels_list, title="t-SNE of Features")
    # plot_tsne(tsne_after_lstm, labels_list, title="t-SNE of Features After LSTM")



def plot_tsne(reduced_features, labels, title):
    """Plot t-SNE results."""
    plt.figure(figsize=(8, 6))
    
    for label in torch.unique(labels):
        idx = labels == label
        plt.scatter(reduced_features[idx, 0], reduced_features[idx, 1], label=f'Class {label.item()}', alpha=0.7)
    
    plt.title(title)
    plt.xlabel('t-SNE Dim 1')
    plt.ylabel('t-SNE Dim 2')
    plt.legend()
    plt.show()


def apply_tsne(features):
    """Apply t-SNE to reduce features to 2D."""
    tsne = TSNE(n_components=2, random_state=42)
    reduced_features = tsne.fit_transform(features)
    return reduced_features


def extract_intermediate_features(self, x):
        """Extract features before and after LSTM."""
        batch_size, seq_len, C, H, W = x.size()
        cnn_features = []
        for t in range(seq_len):
            with torch.no_grad():
                feature = self.cnn(x[:, t, :, :, :])  # CNN output (before LSTM)
            cnn_features.append(feature)
        cnn_features = torch.stack(cnn_features, dim=1)  # Shape: [batch_size, seq_len, cnn_output_dim]
        lstm_out, _ = self.lstm(cnn_features)  # LSTM output
        lstm_out_last = lstm_out[:, -1, :]  # Take the output of the last LSTM cell
        return cnn_features, lstm_out_last

def extract_features(model, loader, device):
    """Extract features before and after the LSTM layer."""
    model.eval()
    features_before_lstm = []
    features_after_lstm = []
    labels_list = []
    
    with torch.no_grad():
        for inputs, labels in loader:
            inputs = inputs.to(device)
            
            # Extract features using the model
            before_lstm, after_lstm = model.extract_intermediate_features(inputs)
            
            # Move features to CPU for t-SNE processing
            features_before_lstm.append(before_lstm.cpu().view(before_lstm.size(0), -1))  # Flatten the CNN features
            features_after_lstm.append(after_lstm.cpu())
            labels_list.append(labels.cpu())

    # Stack features and labels
    features_before_lstm = torch.cat(features_before_lstm, dim=0)
    features_after_lstm = torch.cat(features_after_lstm, dim=0)
    labels_list = torch.cat(labels_list, dim=0)
    
    return features_before_lstm, features_after_lstm, labels_list


