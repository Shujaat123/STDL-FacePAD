import numpy as np
import torch.nn as nn
import torch.optim as optim
import torch
from tqdm import tqdm
from torch.utils.tensorboard import SummaryWriter
import os


writer = SummaryWriter(log_dir='logs')

# Directory to save checkpoints
checkpoint_dir = 'checkpoints'
if not os.path.exists(checkpoint_dir):
    os.makedirs(checkpoint_dir)

# Function to save model checkpoints
def save_checkpoint(state, is_best, filename="checkpoint.pth"):
    torch.save(state, os.path.join(checkpoint_dir, filename))
    if is_best:
        torch.save(state, os.path.join(checkpoint_dir, "best_model.pth"))

# Training loop
def train_epoch(model, loader, criterion, optimizer, epoch, device):
    model.train()
    running_loss = 0.0
    correct = 0
    total = 0
    
    with tqdm(loader, unit="batch") as tepoch:
        for inputs, labels in tepoch:
            tepoch.set_description(f"Epoch {epoch}")
            inputs, labels = inputs.to(device), labels.to(device)
            
            optimizer.zero_grad()
            
            # Forward pass
            outputs = model(inputs)
            
            # Supervised Contrastive Learning (or CrossEntropy)
            loss = criterion(outputs, labels)
            
            # Backpropagation
            loss.backward()
            optimizer.step()
            
            running_loss += loss.item() * inputs.size(0)
            _, predicted = torch.max(outputs, 1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()
            
            tepoch.set_postfix(loss=running_loss/total, accuracy=100. * correct/total)

    epoch_loss = running_loss / len(loader.dataset)
    epoch_acc = 100. * correct / total
    return epoch_loss, epoch_acc

# Validation loop
def validate_epoch(model, loader, criterion, device):
    model.eval()
    running_loss = 0.0
    correct = 0
    total = 0
    with torch.no_grad():
        for inputs, labels in loader:
            inputs, labels = inputs.to(device), labels.to(device)
            
            # Forward pass
            outputs = model(inputs)
            
            # Loss calculation
            loss = criterion(outputs, labels)
            running_loss += loss.item() * inputs.size(0)
            _, predicted = torch.max(outputs, 1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()

    epoch_loss = running_loss / len(loader.dataset)
    epoch_acc = 100. * correct / total
    return epoch_loss, epoch_acc

def train_model(model, train_loader, val_loader, criterion, optimizer, num_epochs, early_stopping_patience, device):
    # Initialize variables to track best validation loss
    best_val_loss = float('inf')
    early_stopping_counter = 0
    for epoch in range(num_epochs):
        # Train and validate for each epoch
        train_loss, train_acc = train_epoch(model, train_loader, criterion, optimizer, epoch, device)
        val_loss, val_acc = validate_epoch(model, val_loader, criterion, device)
        
        # Logging metrics
        writer.add_scalars('Loss', {'train': train_loss, 'val': val_loss}, epoch)
        writer.add_scalars('Accuracy', {'train': train_acc, 'val': val_acc}, epoch)
        
        print(f"Epoch {epoch+1}/{num_epochs}, Train Loss: {train_loss:.4f}, Val Loss: {val_loss:.4f}, Val Acc: {val_acc:.2f}%")

        # Save current checkpoint
        save_checkpoint({
            'epoch': epoch + 1,
            'model_state_dict': model.state_dict(),
            'optimizer_state_dict': optimizer.state_dict(),
            'train_loss': train_loss,
            'val_loss': val_loss,
            'val_acc': val_acc,
        }, is_best=False, filename=f"checkpoint_epoch_{epoch + 1}.pth")

        # Save best model if validation loss improves
        if val_loss < best_val_loss:
            best_val_loss = val_loss
            save_checkpoint({
                'epoch': epoch + 1,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'train_loss': train_loss,
                'val_loss': val_loss,
                'val_acc': val_acc,
            }, is_best=True, filename=f"best_model_epoch_{epoch + 1}.pth")
            early_stopping_counter = 0  # Reset early stopping counter
        else:
            early_stopping_counter += 1

        # Early stopping condition
        if early_stopping_counter >= early_stopping_patience:
            print("Early stopping triggered")
            break

    writer.close()

